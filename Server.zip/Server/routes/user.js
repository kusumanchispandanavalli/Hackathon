const express = require('express')
const CryptoJS= require('crypto-js')
const jwt = require('jsonwebtoken')

const pool = require('../db/db')
const result = require('../utils/result')
const config = require('../utils/config')
const router = express.Router()

router.get('/', (request, response) => {
    const sql = `SELECT * FROM user`
    pool.query(sql, (error, data) => {
        response.send(result.createResult(error, data))
    })
})

router.post('/signin', (request, response) => {
    const { email, password } = request.body
    const encryptedPassword = String(CryptoJS.SHA256(password))

    const sql = `SELECT * FROM user WHERE email = ? AND password = ?`
    pool.query(sql,[email,encryptedPassword],(error, data) => {
        if (data) {
            if (data.length != 0) {
                const payload = {
                    id: data[0].user_id
                }
                const token = jwt.sign(payload, config.secret)
                const body = {
                    token: token,
                    name: `${data[0].full_name} ${data[0].phone_no}`
                }
                response.send(result.createSuccessResult(body))
            }
            else
                response.send(result.createErrorResult("Invalid email or password"))
        }
        else
            response.send(result.createErrorResult(error))
    })
})

router.post('/signup', (request, response) => {
    console.log(request.body)
    const {full_name,email,password,phone_no} = request.body
    const encryptedPassword = String(CryptoJS.SHA256(password))
    const sql = `INSERT INTO user(full_name,email,password,phone_no)
    VALUES(?,?,?,?)`
    pool.query(sql,[full_name,email,encryptedPassword,phone_no] ,(error, data) => {
        response.send(result.createResult(error, data))
    })
})

router.put('/profile', (request, response) => {
    console.log("in profile")
    const {full_name} = request.body
    const sql = `UPDATE user SET full_name=? WHERE user_id=?`
    
    pool.query(sql, [full_name,request.headers.id],(error, data) => {
        console.log(data)
        response.send(result.createResult(error, data))
    })
})

router.delete('/delete', (request, response) => {
    const sql = `DELETE FROM user WHERE user_id = ?`
    pool.query(sql,[request.headers.id], (error, data) => {
        response.send(result.createResult(error, data))
    })
})

module.exports = router