const jwt = require('jsonwebtoken')

const result = require('../utils/result')
const config = require('../utils/config')

function authorization(request, response, next) {
    if (request.url == '/user/signup' ||
        request.url == '/user/signin')
        next()
    else {
        const token = request.headers.token
        if (token) {
            try {
                const payload = jwt.verify(token, config.secret)
                request.headers.user_id = payload.id
                next()
            } catch (e) {
                response.send(result.createErrorResult('Invalid Token'))
            }
        }
        else
            response.send(result.createErrorResult('Token is Missing'))
    }
}

module.exports = authorization 