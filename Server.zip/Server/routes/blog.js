const express = require('express')
const pool = require('../db/db')
const result = require('../utils/result')
const router = express.Router()
//View all blogs
router.get('/', (request, response) => {
    const sql = `SELECT * FROM blog`
    pool.query(sql, (error, data) => {
        response.send(result.createResult(error, data))
    })
})

//Create blog
router.post('/create', (request, response) => {
    const {title, contents ,category_id} = request.body
    const userId = request.headers['id'];

    console.log('Received user_id from headers:', userId);
    const sql = `INSERT INTO blog(title,contents,user_id,category_id)
    VALUES(?,?,?,?)`
    pool.query(sql,[title,contents,userId,category_id] ,(error, data) => {
        response.send(result.createResult(error, data))
    })
})
//Edit Blog
router.put('/profile', (request, response) => {
    const {contents,blog_id} = request.body
    const sql = `UPDATE blog SET contents=? WHERE blog_id=?`
    pool.query(sql, [contents,blog_id],(error, data) => {
        response.send(result.createResult(error, data))
    })
})
//Search Blog  based on category id
router.get('/showcategory', (request, response) => {
    const {category_id}=request.body
    const sql = `SELECT blog_id,title FROM blog where category_id=?`
    pool.query(sql,[category_id],(error, data) => {
        response.send(result.createResult(error, data))
    })
})
//View My Blogs based on user_id
router.get('/showuser', (request, response) => {
    const {user_id}=request.body
    const sql = `SELECT * FROM blog where user_id=?`
    pool.query(sql,[user_id],(error, data) => {
        response.send(result.createResult(error, data))
    })
})

//Delete Blog
router.delete('/delete', (request, response) => {
    const {blog_id} = request.body
    const sql = `DELETE FROM blog WHERE blog_id = ?`
    pool.query(sql,[blog_id], (error, data) => {
        response.send(result.createResult(error, data))
    })
})

module.exports = router