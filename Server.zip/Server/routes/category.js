const express = require('express')
const pool = require('../db/db')
const result = require('../utils/result')
const router = express.Router()

router.get('/', (request, response) => {
    const sql = `SELECT title,description FROM category`
    console.log('category')
    pool.query(sql, (error, data) => {
        response.send(result.createResult(error, data))
    })
})


router.post('/add', (request, response) => {
    const {title,description} = request.body
    const sql = `INSERT INTO category(title,description)
    VALUES(?,?)`
    pool.query(sql,[title,description] ,(error, data) => {
        response.send(result.createResult(error, data))
    })
})

module.exports = router