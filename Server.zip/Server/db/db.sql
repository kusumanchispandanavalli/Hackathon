DROP TABLE if EXISTS USER;
DROP TABLE if EXISTS BLOG;
DROP TABLE if EXISTS CATEGORY;


create table USER(user_id int PRIMARY KEY AUTO_INCREMENT,full_name varchar(50),
email varchar(30),password varchar(200),
phone_no varchar(10),usercreated_time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP);

create table CATEGORY(category_id int PRIMARY KEY AUTO_INCREMENT,title varchar(30),description varchar(50));

create table BLOG(blog_id int PRIMARY KEY AUTO_INCREMENT,title varchar(20),
contents varchar(30),blogcreated_time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
user_id int,category_id int,
foreign key(user_id) references USER(user_id),
foreign key(category_id) references CATEGORY(category_id));


